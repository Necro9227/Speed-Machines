data:extend
(
  {
    {   
    type = "item",
    name = "super-assembler",
    icon = "__speed_machines__/graphics/icons/super_assembler.png",
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "c[super-assembler]",
    place_result = "super-assembler",
    stack_size = 50
    },
  
    {
	type = "item",
	name = "super-smelter",
	icon = "__speed_machines__/graphics/icons/super_smelter.png",
	flags = {"goes-to-quickbar"},
	subgroup = "smelting-machine",
	order = "d[super-smelter]",
	place_result = "super-smelter",
	stack_size = 50
    },

    {
    type = "item",
    name = "ball-bearing",
    icon = "__speed_machines__/graphics/icons/ball_bearing.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "c[ball-bearing]",
    stack_size = 100
    },

    {
    type = "item",
    name = "compressed-coal",
    icon = "__speed_machines__/graphics/icons/compressed_coal.png",
    flags = {"goes-to-main-inventory"},
    fuel_value = "80MJ",
    subgroup = "raw-material",
    order = "c[compressed-coal]",
    stack_size = 50
    },

    {
    type = "item",
    name = "coal-block",
    icon = "__speed_machines__/graphics/icons/coal_block.png",
    flags = {"goes-to-main-inventory"},
    fuel_value = "320MJ",
    subgroup = "raw-material",
    order = "c[coal-block]",
    stack_size = 50
    },

    {
    type = "item",
    name = "burner-auger",
    icon = "__speed_machines__/graphics/icons/burner_auger.png",
    flags = {"goes-to-quickbar"},
    subgroup = "extraction-machine",
    order = "a[items]-c[burner-auger]",
    place_result = "burner-auger",
    stack_size = 50
    },
  }
)