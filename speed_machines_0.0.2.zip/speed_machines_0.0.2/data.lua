require("prototypes.item.items")
require("prototypes.entity.entities")
require("prototypes.recipies.recipies")
require("prototypes.technology.technology")