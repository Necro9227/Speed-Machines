data:extend({
 {
    type = "recipe",
    name = "super-assembler",
    category = "crafting-with-fluid",
    enabled = false,
	energy_required = 60,
    ingredients =
    {
	 {"steel-plate", 10},
	 {"iron-gear-wheel", 12},
	 {"ball-bearing", 8},
	 {"speed-module-3", 2},
	 {"assembling-machine-3", 2},
	 {type="fluid", name="lubricant", amount=10}
    },
    result = "super-assembler"
 },
  
 {
    type = "recipe",
    name = "ball-bearing",
    category = "chemistry",
    enabled = false,
	energy_required = 17.5,
    ingredients =
    {
	 {"iron-plate", 20},
    },
    result = "ball-bearing",
	result_count = 4
 },
    
 {
    type = "recipe",
    name = "compressed-coal",
    category = "crafting",
    enabled = false,
	energy_required = 10,
    ingredients =
    {
	 {"coal", 20},
	},
    result = "compressed-coal"
 },
  
 {
    type = "recipe",
    name = "coal-block",
    category = "crafting",
    enabled = false,
	energy_required = 20,
    ingredients =
    {
	 {"compressed-coal", 20},
	},
    result = "coal-block"
 },
	
 {
    type = "recipe",
    name = "burner-auger",
    category = "crafting",
    enabled = false,
	energy_required = 20,
    ingredients =
    {
	 {"burner-mining-drill", 2},
	 {"ball-bearing", 8},
	 {"steel-plate", 6},
	 {"iron-gear-wheel", 10},
    },
    result = "burner-auger"
 },
 
 {
    type = "recipe",
    name = "super-smelter",
    category = "crafting",
    enabled = false,
	energy_required = 40,
    ingredients =
    {
	 {"electric-furnace", 2},
	 {"speed-module-3", 2},
	 {"ball-bearing", 8},
	 {"steel-plate", 20},
	 {"processing-unit", 2},
    },
    result = "super-smelter"
 },

})