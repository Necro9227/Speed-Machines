data:extend({
	{
	type = "assembling-machine",
	name = "super-assembler",
	icon = "__speed_machines__/graphics/icons/super_assembler.png",
	flags = {"placeable-neutral", "placeable-player", "player-creation"},
	minable = {hardness = 0.2, mining_time = 0.5, result = "super-assembler"},
	max_health = 500,
	corpse = "big-remnants",
	dying_explosion = "medium-explosion",
	resistances =
	{
	{
        type = "fire",
        percent = 70
	}
	},
	fluid_boxes =
	{ 
	{
	production_type = "input",
	pipe_picture = assembler3pipepictures(),
	pipe_covers = pipecoverspictures(),
	base_area = 10,
	base_level = -1,
	pipe_connections = {{ type="input", position = {0, -2} }}
	},
	{ 
	  production_type = "output",
	  pipe_picture = assembler3pipepictures(),
	  pipe_covers = pipecoverspictures(),
	  base_area = 10,
	  base_level = 1,
	  pipe_connections = {{ type="output", position = {0, 2} }}
	},
	  off_when_no_fluid_recipe = true
	},
	  collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
	  selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
	  fast_replaceable_group = "assembling-machine",
	  animation =
   	{
      	  filename = "__speed_machines__/graphics/entity/super_assembler.png",
      	  priority = "high",
      	  width = 113,
      	  height = 99,
      	  frame_count = 32,
      	  line_length = 8,
      	  shift = {0.4, -0.06}
    	},
    	  open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    	  close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    	  vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
 	      working_sound =
   	{
      	  sound = {
        {
          filename = "__base__/sound/assembling-machine-t2-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t2-2.ogg",
          volume = 0.8
        },
      },
        idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
        apparent_volume = 1.5,
    },
      crafting_categories = {"crafting", "advanced-crafting", "crafting-with-fluid"},
      crafting_speed = 10,
      energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.3 / 2.5
    },
      energy_usage = "1000kW",
      ingredient_count = 8,
      module_specification =
    {
      module_slots = 6
    },
      allowed_effects = {"consumption", "speed", "productivity", "pollution"}
  },
  
  {
    type = "mining-drill",
    name = "burner-auger",
    icon = "__speed_machines__/graphics/icons/burner_auger.png",
    flags = {"placeable-neutral", "player-creation"},
    resource_categories = {"basic-solid"},
    minable = {mining_time = 1, result = "burner-auger"},
    max_health = 150,
    corpse = "medium-remnants",
    collision_box = {{ -0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{ -1, -1}, {1, 1}},
    mining_speed = 3.25,
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/burner-mining-drill.ogg",
        volume = 0.8
      },
    },
    energy_source =
    {
      type = "burner",
      effectivity = 3,
      fuel_inventory_size = 1,
      emissions = 0.25 / 2.5,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 3
        }
      }
    },
    energy_usage = "900kW",
    mining_power = 3.0,
    animations =
    {
      north =
      {
        priority = "extra-high",
        width = 110,
        height = 76,
        line_length = 4,
        shift = {0.6875, -0.09375},
        filename = "__speed_machines__/graphics/entity/augernorth.png",
        frame_count = 32,
        animation_speed = 0.5,
        run_mode = "forward-then-backward",
      },
      east =
      {
        priority = "extra-high",
        width = 94,
        height = 74,
        line_length = 4,
        shift = {0.4375, -0.09375},
        filename = "__speed_machines__/graphics/entity/augereast.png",
        frame_count = 32,
        animation_speed = 0.5,
        run_mode = "forward-then-backward",
      },
      south =
      {
        priority = "extra-high",
        width = 89,
        height = 88,
        line_length = 4,
        shift = {0.40625, 0},
        filename = "__speed_machines__/graphics/entity/augersouth.png",
        frame_count = 32,
        animation_speed = 0.5,
        run_mode = "forward-then-backward",
      },
      west =
      {
        priority = "extra-high",
        width = 91,
        height = 78,
        line_length = 4,
        shift = {0.09375, -0.0625},
        filename = "__speed_machines__/graphics/entity/augerwest.png",
        frame_count = 32,
        animation_speed = 0.5,
        run_mode = "forward-then-backward",
      }
    },
    resource_searching_radius = 0.99,
	vector_to_place_result = {-0.5, -1.3},
    fast_replaceable_group = "mining-drill"
  },
  
  {
    type = "furnace",
    name = "super-smelter",
    icon = "__speed_machines__/graphics/icons/electric-furnace.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "super-smelter"},
    max_health = 150,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    light = {intensity = 1, size = 10},
    resistances =
    {
      {
        type = "fire",
        percent = 80
      }
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    module_specification =
    {
      module_slots = 4,
      module_info_icon_shift = {0, 0.8}
    },
    allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    crafting_categories = {"smelting"},
    result_inventory_size = 2,
    crafting_speed = 8,
    energy_usage = "1000kW",
    source_inventory_size = 2,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.5/1.5
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/electric-furnace.ogg",
        volume = 0.7
      },
      apparent_volume = 1.5
    },
    animation =
    {
      filename = "__speed_machines__/graphics/entity/electric-furnace-base.png",
      priority = "high",
      width = 129,
      height = 100,
      frame_count = 1,
      shift = {0.421875, 0}
    },
    working_visualisations =
    {
      {
        animation =
        {
          filename = "__speed_machines__/graphics/entity/electric-furnace-heater.png",
          priority = "high",
          width = 25,
          height = 15,
          frame_count = 12,
          animation_speed = 0.5,
          shift = {0.015625, 0.890625}
        },
        light = {intensity = 0.4, size = 6, shift = {0.0, 1.0}}
      },
      {
        animation =
        {
          filename = "__speed_machines__/graphics/entity/electric-furnace-propeller-1.png",
          priority = "high",
          width = 19,
          height = 13,
          frame_count = 4,
          animation_speed = 0.5,
          shift = {-0.671875, -0.640625}
        }
      },
      {
        animation =
        {
          filename = "__speed_machines__/graphics/entity/electric-furnace-propeller-2.png",
          priority = "high",
          width = 12,
          height = 9,
          frame_count = 4,
          animation_speed = 0.5,
          shift = {0.0625, -1.234375}
        }
      }
    },
    fast_replaceable_group = "furnace"
  }
}
)