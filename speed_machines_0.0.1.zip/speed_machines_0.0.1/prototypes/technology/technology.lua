data:extend({
    {
    type = "technology",
    name = "automation-super",
    icon = "__base__/graphics/technology/automation.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "super-assembler"
      },
      {
        type = "unlock-recipe",
        recipe = "super-smelter"
      },
	  {
        type = "unlock-recipe",
        recipe = "coal-block"
      },
    },
    prerequisites = {"automation-3", "speed-module-3"},
    unit =
    {
      count = 300,
      ingredients = 
	{
	   {"science-pack-1", 1}, 
	   {"science-pack-2", 1}, 
	   {"science-pack-3", 1},
	},
      time = 60
    },
    order = "a-b-d"
  },
  {
    type = "technology",
    name = "advanced-mining",
    icon = "__base__/graphics/icons/electric-mining-drill.png",
    effects =
    {
	{
        type = "unlock-recipe",
        recipe = "burner-auger"
	},
	{
        type = "unlock-recipe",
        recipe = "ball-bearing"
	},
	{
        type = "unlock-recipe",
        recipe = "compressed-coal"
	},
    },
    prerequisites = { "steel-processing", "oil-processing"},
    unit = {
      count = 50,
      ingredients = {
        {"science-pack-1", 2},
        {"science-pack-2", 2}
      },
      time = 30
    },
    order = "c-g-b",
  },
 }
)